#!/usr/bin/env python3

import os
try:
    from setuptools import setup
except ImportError:
    from ez_setup import use_setuptools
    use_setuptools()
    from setuptools import setup

long_description = """This module provides musical tools for inspire musical creations."""

setup(
    name = 'muser',
    version = '1.0',
    description = 'Give help to your music',
    author = 'Nicolas Pauer',
    url = 'https://github.com/NicoPauer/muser',
    packages = ['muser'],
    install_requires = [],
    license = 'MIT',
    long_description = long_description
)
