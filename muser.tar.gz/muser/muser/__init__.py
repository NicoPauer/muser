#!/usr/bin/python3

from .muser import *

__version__ = '1.0'

__name__ = 'muser'

__author__ = 'Nicolas Pauer'

__license__ = 'MIT'

__copyright__ = 'Copyright (c) February of 2023'
