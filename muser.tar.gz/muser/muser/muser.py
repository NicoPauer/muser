#!/usr/bin/python3


class muser():

    def __init__(self, name):
        '''
            Copyright (c) February of 2023 by Nico Pauer.

            Muser v1.0 --> A module to inspire music creations.
        '''
      # Define a name to the musical object
        self.ID = name
      # Define an array to save the scale notes depending of the tonality used by the method muser.tonality
        self.scale = []
      # Define the scale structure by default is a major scale but can changes
        self.scaleType = 'major'
      # Define translation for some musical notation in a dictionary
        self.notationDict = {'M':'major', 'major':'M', 'm':'minor', 'minor':'m', 'aug':'augmented', 'augmented':'aug', 'dim':'disminuted', 'disminuted':'dim', '°':'disminuted', 'disminuted':'°', 'C#':'Db', 'D#':'Eb', 'F#':'Gb', 'G#':'Ab', 'A#':'Bb'}
      # Define an array with the notes name in american cipher: naturals and altered
        self.notes = ['A', 'A#', 'B', 'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#']

    def semitone(self, note):
        '''
            Find the note to one semitone of distance.
        '''
       # Init local vars for method intern use and help
        start = self.notes.index(note)
        result = note 
       # Only go to next note, the nearest if this isn't the last note
        if (start < (self.notes.__len__() - 1)):
        # Go to the next note, the distance between two notes consecutives is a semitone
            result = self.notes[start + 1] 
        elif (start == (self.notes.__len__() - 1)):
        # I know the last note is G#, the next note to one semitone is the A of the same octave
            result = 'A'

        return result
        

    def tone(self, note):
        '''
            Find the note to one tone of distance.
        '''
       # Two semitones is equal to one tone 
        result = self.semitone(note)

        result = self.semitone(result)

        return result

    def tonality(self, tonic):
        '''
            Specify a tonality for the object, modify the array muser.scale.
        '''
       # Save an aux copy of the tonic in case of emergency
        auxTonality = tonic
       # Take the tonic without the tonality name(no minor, major, disminuted nor augmented)
        tonic = tonic.replace('m', '')
        tonic = tonic.replace('M', '')
        tonic = tonic.replace('°', '')
        tonic = tonic.replace('dim', '')
        tonic = tonic.replace('aug', '')
       # Use aux copy for change the scale note to minor, disminuted or augmented in case of be needed

        auxTonality = auxTonality.replace(tonic, '')

        if (self.notationDict.__contains__(auxTonality)):
        # Only change if this isn't major that happens is blank space(out of naotationDict) or auxTonality is the capital letter 'M'
            self.scaleType = self.notationDict[auxTonality]

       # Put the first note on the scale
        self.scale.append(tonic)
       # Put the rest of the notes
       # Counting since the tonic the structure is the next
       ### major: tone-tone-semitone-tone-tone-tone-semitone
       ### minor: tone-semitone-tone-tone-semitone-tone-tone
       ### disminuted: semitone-
       ### augmented: tone-
        if (self.scaleType == 'major'):
          # This is can be more simple in the future now is made this way to launch fast the project
            self.scale.append(self.tone(tonic))
            self.scale.append(self.tone(scale[2]))
            self.scale.append(self.semitone(scale[3]))
            self.scale.append(self.tone(scale[4]))
            self.scale.append(self.tone(scale[5]))
            self.scale.append(self.tone(scale[6]))
            self.scale.append(self.semitone(scale[7]))

        elif (self.scaleType == 'minor'):

            self.scale.append(self.tone(tonic))
            self.scale.append(self.semitone(scale[2]))
            self.scale.append(self.tone(scale[3]))
            self.scale.append(self.tone(scale[4]))
            self.scale.append(self.semitone(scale[5]))
            self.scale.append(self.tone(scale[6]))
            self.scale.append(self.tone(scale[7]))

        elif (self.scaleType == 'disminuted'):

            self.scale.append(self.semitone(tonic))

        elif (self.scaleType == 'augmented'):

            self.scale.append(self.tone(tonic))

    def chords(self, grades):
        '''
            Note: Use tonality mehtod before or this give an error.

            Return the chords in the scale using as parameter an array with strings in roman number format very used in musical theory.
        '''
       # The requested chords
        result = []
       # The order in that be added the chords
        order = {}
       # Add the requested chords
       # Chord I
        if (grades.__contains__('I')):
            result.append(self.scale[0] + self.notationDict[self.scaleType])
            order['I'] = 0
       # Chord II
        if (grades.__contains__('II')):
            second = {'major':'m', 'minor':'dim'}
            result.append(self.scale[1] + second[self.scaleType])
            order['II'] = 1
       # Chord III
        if (grades.__contains__('III')):
            third = {'major':'', 'minor':'aug'}
            result.append(self.scale[1] + third[self.scaleType])
            order['III'] = 2
       # Chord IV
        if (grades.__contains__('IV')):
            fourth = {'major':'', 'minor':'m'}
            result.append(self.scale[1] + fourth[self.scaleType])
            order['IV'] = 3
       # Chord V
        if (grades.__contains__('V')):
            five = {'major':'', 'minor':''}
            result.append(self.scale[1] + five[self.scaleType])
            order['V'] = 4
       # Chord VI
        if (grades.__contains__('VI')):
            sixth = {'major':'m', 'minor':''}
            result.append(self.scale[1] + sixth[self.scaleType])
            order['VI'] = 5
       # Chord VII
        if (grades.__contains__('VII')):
            seventh = {'major':'dim', 'minor':'dim'}
            result.append(self.scale[1] + seventh[self.scaleType])
            order['VII'] = 6
       # Sort the result before of return it
        for grade in order:

            if (order[grade] != grades.index(grade)):
             # Sort by interchanging the chords
                result[order(grade)] = result[grades.index(grade)]
                result[grades.index(grade)] = grade 
 
        return result
