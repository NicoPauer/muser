Muser Python Musical Module
===

Copyright (c) February of 2023 by Nico Pauer.

Muser is a Module to help in the songs creation with
objects to recommend chords, scale, rythms and more
musical aspects to improve the songs composition.

> This is open source under  license because able you to distribute copys and/or modify
the code and you can use to some commercial purposes if you want to can use in projects
such as make pop music, musical plugins and another commercial music uses, read the 'LICENSE'
text file before of make any of them actions. Use this under your own risk, I dsiclaim from
any liable or warranty about this module, derivative software and/or his possible uses.

Dependencies
-------
```
-- python3
-- ez_setup
-- setuptools
-- pip-python3
```
Install
-------
> sudo -k python3 setup.py install.
Usage
-------
```python
from muser import *


# Create a muser object with the ID 'Example1' to create some musical patterns
objectName = muser('Example1')
# Set tonality in A major
objectName.tonality('A')
# Get some chords with use A major scale and save in result
result = objectName.chords(['I', 'II', 'IV', 'V']) 
# Show the next, I-II-IV-V: A-Bm-D-E
print(result)
# Get anothers chords with use A major scale and save in result
result = objectName.chords(['I', 'V', 'VI', 'IV']) 
# Show the next, I-V-VI-IV: A-E-F#m-D
print(result)
# Show the scale, A major scale in this case.
# A major, notes: A, B, C#, D, E, F#, G#, A 
print('A major notes: ' + objectName.scale.join(', '))
```
License
-------

MIT License.
