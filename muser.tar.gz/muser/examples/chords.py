#!/usr/bin/python3

from muser import *


common1 = muser('I-II-IV-V Progression')

common2 = muser('I-V-VI-IV Progression')

print("I've the next musical objects: \n")

print('1) %s:\t\n' + common1.ID)

print(common1.chords(['I', 'II', 'IV', 'V']) + '\n')

print('2) %s:\t\n' + common2.ID)

print(common1.chords(['I', 'V', 'VI', 'IV']) + '\n')

print('I used chords getter from muser module of the class muser')
