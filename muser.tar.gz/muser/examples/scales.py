#!/usr/bin/python3


from muser import *

# Example of scale using muser
scale1 = muser('Scale Example')

scale1.tonality('A')

print(scale1.scale[0] + ' ' + scale1.scaleType + ': ' + scale1.scale)

scale2 = scale1

scale2.tonality('Em')

print(scale2.scale[0] + ' ' + scale2.scaleType + ': ' + scale2.scale)
